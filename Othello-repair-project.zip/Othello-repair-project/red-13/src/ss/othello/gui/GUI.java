package ss.othello.gui;

import java.io.Serializable;

public interface GUI extends Serializable {

	public String getUserName();

	public void setUserName(String userName);

}

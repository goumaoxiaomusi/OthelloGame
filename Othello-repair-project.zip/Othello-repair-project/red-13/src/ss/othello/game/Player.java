package ss.othello.game;

/**
 * This class represents a player.
 */
public interface Player {

    public String getName();

    public Mark getMark();

}
#Red-13


## Name
Othello Online Game Application

## Description
This application allows multiple players to play Othello online. The game provides players with four different modes of playing: play with random people, play with a specific person, 
play with an easy computer, play with a hard computer. Players can choose their opponent based on their rank.


## Usage
Start the server and then start clients

The server is the class called ServerFrame in server package. 
The client part is the StartPageGUI in gui package.

If you do not have account in the system, do not worry. You can choose a username and enter your password on the Start Page, you will be automatically signed up and logged in. 
If your came up username is taken, the system will tell you wrong password and username combination. Then, you can enter another prefered name. 
Once you are signed up, we will give you an initial score of 0. Once you win over a game, your score will go up 1 and you can check your score at the rank button during the game or choosing an opponent.

You cannot login your accont twice.There will be an warning.

If you already have an account before, you can just login.

After you are logged in, you will be direct to a choose mode page. If you and your friends want to play the game together, one of you can click "Wait to be Invited" and the other can click
choose an opponent to play, which allows the player to choose a player who is waiting to be invited.

If you do not know anyone, you can click play with random people. To keep in mind, no matter what mode you choose, as long as you are playing with human players, you need to 
gain their permission. Thus, under the play with random people mode, if all the waiting players in the waiting list are asked, you will have no one to play. But you can choose
to play with a hard or easy computer.

In the game, you will have a game room number and when it is your turn, you will see hollow circles on the board. You can only click on the hollow circles, any other buttons are invalid.

During the game you can give up by clicing the give up button or exit the window. But, if you do that you automatically lose to your opponent.

The system will ask you if you want to play another game or not. If you click yes, you will be redirect to the Choose Mode page. If you click no, the system will exit.

Have fun!

## Authoer
Yujun Li
